from .main import Beacon  # noqa: F401
