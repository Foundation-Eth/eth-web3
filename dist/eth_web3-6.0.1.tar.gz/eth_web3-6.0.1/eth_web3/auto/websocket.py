from eth_web3 import (
    Web3,
    WebsocketProvider,
)

w3 = Web3(WebsocketProvider())
